export class EmployeeDetail {
    
    empAddress: string= ""
    empContact: string= ""
    empEmail: string= ""
    empId:  number=0
    empName: string= ""
}
