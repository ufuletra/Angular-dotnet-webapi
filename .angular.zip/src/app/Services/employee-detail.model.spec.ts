import { EmployeeDetail } from './employee-detail.model';

describe('EmployeeDetail', () => {
  it('should create an instance', () => {
    expect(new EmployeeDetail()).toBeTruthy();
  });
});
