export const environment = {
 apiBaseUrl: 'http://localhost:5244/api'

}; 