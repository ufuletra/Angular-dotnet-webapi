// node_modules/@angular/cdk/fesm2022/coercion.mjs
function coerceBooleanProperty(value) {
  return value != null && `${value}` !== "false";
}

export {
  coerceBooleanProperty
};
//# sourceMappingURL=chunk-U2O2N5MM.js.map
