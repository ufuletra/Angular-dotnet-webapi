import {
  MatDivider,
  MatDividerModule
} from "./chunk-CGHAWU5J.js";
import "./chunk-U2O2N5MM.js";
import "./chunk-33YLY63T.js";
import "./chunk-TJWKQZUR.js";
import "./chunk-QL5OXR7T.js";
import "./chunk-QFYFK63A.js";
import "./chunk-OXE7ACSC.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
